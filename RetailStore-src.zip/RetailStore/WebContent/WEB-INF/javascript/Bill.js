/**
 * 
 */
(function(bill, $, ko) {
	'use strict';
	var self = this;
	
	
	Item = function(){
		self.name= "";
		self.price ="";
		self.category= "";
		self.salesTax= "";
		self.priceAndSalesTax="";
	}
	
	self.totalBill = ko.computed(function(){
		for(var item in selectedItems){
			totalBill = totalBill + item.priceAndSalesTax;
		}
	},self);
	
	self.order = ko.observable();
	var getPrepareBillUrl = '/RetailStore-1/checkout';
	function checkout(){
	$.ajax({
		url : getPrepareBillUrl,
		type : "GET",
		data : bill.toJSON(self),
		contentType : "application/json",
		success : function(data, status) {
			self.loadItems(data);
					
		},
		error : function(data, status) {
			store.displayMessage(self.message, {
				message : 'Error Getting Items',
				messageType : 'ERROR'
			});
		}
	});
	}
	self.loadItems = function(model) {
		if (model) {
			for ( var k = 0; k < model.length(); k++) {
				item = new Item(model.name,model.price,model.category,model.salesTax);
				item.priceAndSalesTax = ko.computed(function() {
					return price+ salesTax;
				},self)
				order.push(item);
				
			}
		}
	};
	
	ko.applyBindings(bill);
}(window.bill = window.bill || {}, jQuery,ko));