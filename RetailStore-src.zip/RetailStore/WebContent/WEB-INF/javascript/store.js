/**
 * 
 */
(function(store, $, ko) {
	'use strict';
	var self = this;
	
	Item = function(){
		self.name= "";
		self.price ="";
		self.category= "";
		self.selected= false;
	}

	self.items = ko.observable();
	var gerAllItemsUrl = '/RetailStore-1/getAllItems';
	$.ajax({
		url : gerAllItemsUrl,
		type : "GET",
		data : store.toJSON(self),
		contentType : "application/json",
		success : function(data, status) {
			self.loadItems(data);
					
		},
		error : function(data, status) {
			store.displayMessage(self.message, {
				message : 'Error Getting Items',
				messageType : 'ERROR'
			});
		}
	});
	
	self.loadItems = function(model) {
		if (model) {
			for ( var k = 0; k < model.length(); k++) {
				item = new Item(model.name,model.price,model.category);
				items.push(item);
			}
		}
	};
	
	ko.applyBindings(store);
}(window.store = window.store || {}, jQuery,ko));