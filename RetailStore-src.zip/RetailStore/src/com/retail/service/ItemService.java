package com.retail.service;

import java.util.List;

import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Service;

import com.retail.model.Item;
@Configuration
@Service
public interface ItemService {
	public List<Item> getAllItems();
}
