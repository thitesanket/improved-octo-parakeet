package com.retail.service;

import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Service;
import com.retail.model.Order;

@Configuration
@Service
public interface BillService {
	
	
	Order processSelectedItems(Order order);
		
	int getSalesTax(String category);
		
}
