package com.retail.service.impl;

import java.util.List;

import org.springframework.context.annotation.Bean;

import com.retail.dao.ItemDao;
import com.retail.model.Item;
import com.retail.service.ItemService;

public class ItemServiceImpl implements ItemService{
	ItemDao itemDao; 
	@Bean
	public ItemDao getItemDao() {
		return itemDao;
	}

	public void setItemDao(ItemDao itemDao) {
		this.itemDao = itemDao;
	}

	public List<Item> getAllItems(){
		return itemDao.getAllItems();
	}
}
