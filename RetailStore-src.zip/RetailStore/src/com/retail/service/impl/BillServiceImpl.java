package com.retail.service.impl;

import java.util.Map;

import com.retail.helper.SalesTaxFactory;
import com.retail.model.Item;
import com.retail.model.Order;
import com.retail.service.BillService;

public class BillServiceImpl implements BillService{
	public Order processSelectedItems(Order order){
		for(Item item: order.getItem()){
		 item.setSalesTax(getSalesTax(item.getCategory())); 
		}
		return order;
	}
	public int getSalesTax(String category){
		int salesTax=0;
		Map<String,SalesTaxFactory> map = SalesTaxFactory.getMapSalesTaxFactories();
		if(map.containsKey(category)){
			salesTax = map.get(category).getSalesTax();
		}
		return salesTax;
	}
}
