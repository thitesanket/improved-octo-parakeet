package com.retail.helper;

import java.util.HashMap;
import java.util.Map;

public enum SalesTaxFactory {
	CATEGORY_A("A"){
		public int getSalesTax(){
			return 10;
		}
	},
	CATEGORY_B("B"){
		public int getSalesTax(){
			return 20;
		}
	},
	CATEGORY_C("C"){
		public int getSalesTax(){
			return 30;
		}
	};
	String category;
	public abstract int getSalesTax();	
	
	private SalesTaxFactory(String category){
		this.category = category;
	}
	public static Map getMapSalesTaxFactories(){
		Map<String,SalesTaxFactory> map = new HashMap<String,SalesTaxFactory>();
		map.put("A", SalesTaxFactory.CATEGORY_A);
		map.put("B", SalesTaxFactory.CATEGORY_B);
		map.put("C", SalesTaxFactory.CATEGORY_C);
		return map;
	}
}
