package com.retail.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.orm.hibernate3.HibernateTemplate;

import com.retail.model.Order;

public class OrderDao {
	HibernateTemplate template;

	public void setTemplate(HibernateTemplate template) {
		this.template = template;
	}
	public void saveOrder(Order order){
		template.save(order);
	}
	public void updateOrder(Order order){
		template.update(order);
	}
	public void deleteOrder(Order order){
		template.delete(order);
	}
	public Order getOrder(int id){
		Order order = (Order)template.get(Order.class, id);
		return order;
	}
	public List<Order> getOrders(){
		List<Order> orders = new ArrayList<Order>();
		orders= template.loadAll(Order.class);
		return orders;
		
	}
}
