package com.retail.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.orm.hibernate3.HibernateTemplate;

import com.retail.model.Item;

public class ItemDao {
	HibernateTemplate template;
	public void setTemplate(HibernateTemplate template) {
		this.template = template;
	}
	public void saveItem(Item Item){
		template.save(Item);
	}
	public void updateItem(Item Item){
		template.update(Item);
	}
	public void deleteItem(Item Item){
		template.delete(Item);
	}
	public Item getItem(int id){
		Item Item = (Item)template.get(Item.class, id);
		return Item;
	}
	public List<Item> getAllItems(){
		List<Item> items = new ArrayList<Item>();
		items= template.loadAll(Item.class);
		return items;
		
	}
}
