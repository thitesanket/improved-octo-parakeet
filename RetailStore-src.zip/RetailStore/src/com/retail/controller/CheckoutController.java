package com.retail.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.retail.model.Order;
import com.retail.service.BillService;
import com.retail.service.ItemService;

@RestController
public class CheckoutController {
	@Autowired
	BillService billService;
	@Autowired
	ItemService itemService;
	@RequestMapping(value= "/checkout",method = RequestMethod.GET)
	public @ResponseBody Order checkout(@RequestParam("uname") String name,@RequestBody Order order,Model model){
		Order selectedOrder = billService.processSelectedItems(order);
		return selectedOrder;
	}
	
	@RequestMapping(value="/getAllItems")
	public @ResponseBody String getAllItems(){
		
		return "";
	}
	@Bean
	public BillService getBillService() {
		return billService;
	}
	
	public void setBillService(BillService billService) {
		this.billService = billService;
	}
	@Bean
	public ItemService getItemService() {
		return itemService;
	}

	public void setItemService(ItemService itemService) {
		this.itemService = itemService;
	}
	
	
}
