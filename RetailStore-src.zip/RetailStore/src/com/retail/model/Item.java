package com.retail.model;

import javax.persistence.Column;
import javax.persistence.Id;

import org.hibernate.annotations.Table;

@Table(appliesTo="ITEM")
public class Item {
	@Id
	public int id;
	@Column
	public String name;
	@Column
	public int price;
	@Column
	public String category;
	
	public double salesTax;
	public Item(int id, String name, int price, String category) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
		this.category = category;
	}
	public Item(){}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}
	public double getSalesTax() {
		return salesTax;
	}
	public void setSalesTax(double salesTax) {
		this.salesTax = salesTax;
	}
	


}
