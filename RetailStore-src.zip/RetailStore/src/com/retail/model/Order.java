package com.retail.model;

import java.util.Set;

import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;



@Table(name="Order")
public class Order {
	@Id
	public int id;
	@OneToMany(fetch=FetchType.LAZY,mappedBy="id")
	Set<Item> item;
	
	public Order(){}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public Set<Item> getItem() {
		return item;
	}

	public void setItem(Set<Item> item) {
		this.item = item;
	}

	

	
}
